# Customizable-ID-Card-Generator
Design a customizable ID card generator with predefined templates. Organizers can configure name, college/team position, adjust text placement, and customize appearance (color/font). Live preview ensures review before generating print-ready version.
